﻿    $(document).ready(function () {
        $('.js-example-basic-multiple').select2({
            placeholder: "Select a state",
        });

        $(".js-example-placeholder-single").select2({
            placeholder: "Member",
            allowClear: true
        });

    });


  